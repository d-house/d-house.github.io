
#include "Quaternion.h"

using namespace std;

int main(){
  Quaternion q1, q2, q3, q4;
  Vector3d v0(1, 0, 0);
  Quaternion qout;

  q1.set(45, 0, 0);	  // yaw 45 degs.
  cout << "q1 = " << q1 << endl;
  q2.set(0, 45, 0);	  // pitch 45 degs.
  cout << "q2 = " << q2 << endl;
  q3.set(0, 0, 45);	  // roll 45 degs.
  cout << "q3 = " << q3 << endl;
  q4.set(45, 45, 45);	  // yaw, pitch, roll 45 degs.
  cout << "q4 = " << q4 << endl;

  cout << "v0 = " << v0 << ", q0 = " << Quaternion(v0) << endl;
  qout = q1 * Quaternion(v0) * q1.inv();
  cout << "v1 = " << Vector3d(qout) << endl;
  qout = q2 * Quaternion(v0) * q2.inv();
  cout << "v2 = " << Vector3d(qout) << endl;
  qout = q3 * Quaternion(v0) * q3.inv();
  cout << "v3 = " << Vector3d(qout) << endl;
  qout = q4 * Quaternion(v0) * q4.inv();
  cout << "v4 = " << Vector3d(qout) << endl;
  
  double c = cos(DegToRad(45)), s = sin(DegToRad(45));
  Matrix3x3 yaw (c, 0, s, 0, 1, 0, -s, 0, c);
  Matrix3x3 tilt(1, 0, 0, 0, c, -s, 0, s, c);
  Matrix3x3 roll(c, -s, 0, s, c, 0, 0, 0, 1);
  Vector vout;
  vout = roll * tilt * yaw * v0;
  cout << "vm = " << vout << endl;  
  
  return 0;
}
