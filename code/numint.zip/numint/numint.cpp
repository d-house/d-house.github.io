/*
   Sample OpenGL Program to Demonstrate Numerical Integration

   VIZA 659            Donald H. House         9/26/2004

*/

#include <cstdio>	/* definitions for standard I/O routines */
#include <cmath>
#include <cstring>

#ifdef __APPLE__
#  include <GLUT/glut.h>
#else
#  include <GL/glut.h>
#endif

#include "Vector.h"

using namespace std;

#define WIDTH       900
#define HEIGHT      600

#define Exact       0
#define Euler       1
#define Midpoint    2
#define RK4	    3

static Vector2d XIC(1, 0);
static const double TC(1);
static double H = TC;
static int Sine = 0;

static int O1 = 1;
static int O2 = 0;
static int O4 = 0;

static int MouseX, MouseY;
static int LeftButton = 0;
static double Scale = 1;

//
// Display a string of text using OpenGl's Bitmap Characters
//
void displayText(char *t)
{
  if(t == NULL)
    return;

  for(int i = 0; i < int(strlen(t)); i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, t[i]);
}

Vector2d f(Vector2d x, double t, double T){
  Vector2d dxdt;
  double omega = 2 * PI / T;
  
  if(Sine){
    dxdt.x = x.y;
    dxdt.y = -Sqr(omega) * x.x;
  }
  else
    dxdt =  -x / T;
    
  return dxdt;
}

Vector2d numint(Vector2d x, double t, Vector2d X0, double T, double h, int method){
  Vector2d K1, K2, K3, K4;
  
  switch(method){
    case Exact:
      if(Sine){
	double omega = 2 * PI / T;
	Vector2d xexact;
	xexact.x = X0.x * cos(omega * (t + h));
	xexact.y = -X0.x * omega * sin(omega * (t + h));
	return xexact;
      }
      else
	return X0 * exp(-(t + h) / T);
    break;
  
    case Euler:
      return x + h * f(x, t, T);
    break;
  
    case Midpoint:
      K1 = h * f(x, t, T);
      K2 = h * f(x + K1 / 2, t + h / 2, T);
      return x + K2;
    break;
    
    case RK4:
      K1 = h * f(x, t, T);
      K2 = h * f(x + K1 / 2, t + h / 2, T);
      K3 = h * f(x + K2 / 2, t + h / 2, T);
      K4 = h * f(x + K3, t + h, T);
      return x + (K1 + 2 * K2 + 2 * K3 + K4) / 6;    
    break;
  }
}

void drawcurve(double x0, double T, double h, int method){
  Vector2d x, dxdt;
  double t;
  
  glBegin(GL_LINE_STRIP);
    for(t = 0, x = x0; t <= 4 * T / Scale; t += h){
      dxdt = f(x, t, T);
      glVertex2f(t, x.x);
      x = numint(x, t, x0, T, h, method);
    }
  glEnd();
}

void drawAxes(Vector2d x0, double T){
  glBegin(GL_LINES);
    glVertex2f(0, -1.05 * x0.x / Scale);
    glVertex2f(0, 1.05 * x0.x / Scale);
    glVertex2f(-0.1 * (4 * T) / Scale, 0);
    glVertex2f(4 * T / Scale, 0);
  glEnd();
}

void displayH(double h){
  char str[256];
  
  glRasterPos2f(3.5 * TC / Scale, 0.75 * XIC.x / Scale);
  glColor3f(0, 0, 0);
  if(h == TC)
    sprintf(str, "h = T");
  else if(h > TC)
    sprintf(str, "h = %d T", int(h / TC));
  else
    sprintf(str, "h = T/%d", int(TC / h));
  displayText(str);
}

/*
   Display Callback Routine: clear the screen and draw a square
   This routine is called every time the window on the screen needs
   to be redrawn, like if the window is iconized and then reopened
   by the user. It is also called when the window is first created.
*/
void drawCurves(){
		
  /* clear the window to the background color */
  glClear(GL_COLOR_BUFFER_BIT);

  glLineWidth(2);

  /* draw the curves */
  glColor3f(0, 0, 0);		      /* make exact curve and axes black */
  drawAxes(XIC.x, TC);
  drawcurve(XIC.x, TC, 0.05, Exact);

  if(O1){
    glColor3f(1, 0, 0);		      /* make euler curve red */
    drawcurve(XIC.x, TC, H, Euler);
  }

  if(O2){
    glColor3f(0, 1, 0);		      /* make midpoint curve green */
    drawcurve(XIC.x, TC, H, Midpoint);
  }

  if(O4){
    glColor3f(0.2, 0.2, 1);	      /* make RK4 curve blue */
    drawcurve(XIC.x, TC, H, RK4);
  }
 
  glColor3f(0, 0, 0);		      /* make exact curve and axes black */
  displayH(H);
  
  glFlush();
}

void handleSpecialKey(int key, int x, int y){

  int shift = (glutGetModifiers() == GLUT_ACTIVE_SHIFT); // store shift key

  switch(key){
  case GLUT_KEY_LEFT:	// decrease
    if(shift)
      H -= 0.1;
    else
      H /= 2;
  break;

  case GLUT_KEY_RIGHT:	// increase
    if(shift)
      H += 0.1;
    else
      H *= 2;
  break;

  default:		// not a valid key -- just ignore it
    return;
  }

  glutPostRedisplay();
}

void handleKey(unsigned char key, int x, int y){

  switch(key){
  case '1':
    O1 = !O1;
    break;
  case '2':
    O2 = !O2;
    break;
  case '4':
    O4 = !O4;
    break;
  case 's':
  case 'S':
    Sine = !Sine;
    break;
    
  case 'q':		// q - quit
  case 'Q':
  case 27:		// esc - quit
    exit(0);

  default:		// not a valid key -- just ignore it
    return;
  }
  
  glutPostRedisplay();
}

void handleButton(int button, int state, int x, int y){

  if(state == GLUT_DOWN && button == GLUT_LEFT_BUTTON){
    LeftButton = 1;
    MouseY = -y;
    MouseX = x;
  }
  else
    LeftButton = 0;
}

void handleMotion(int x, int y){

  y = -y;
  int dy = y - MouseY;
  int dx = x - MouseX;

  if(LeftButton){
    if(1 + 0.1 * dy > SMALLNUMBER){
      glScalef(1 + 0.1 * dy, 1 + 0.1 * dy, 1 + 0.1 * dy);
      Scale = Scale * (1 + 0.1 * dy);
    }
    glutPostRedisplay();
  }

  MouseX = x;
  MouseY = y;
}

/*
   Main program to draw the squre and wait for quit
*/
int main(int argc, char* argv[]){

  /* start up the glut utilities */
  glutInit(&argc, argv);

  /* create the graphics window, giving width, height, and title text */
  glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
  glutInitWindowSize(WIDTH, HEIGHT);
  glutCreateWindow("Numerical Integration");

  /* the routine to call to draw graphics when glutMainLoop() is called */
  glutDisplayFunc(drawCurves);
  glutSpecialFunc(handleSpecialKey);
  glutKeyboardFunc(handleKey);
  glutMotionFunc(handleMotion);
  glutMouseFunc(handleButton);

  /* lower left of window is (0, 0), upper right is (WIDTH, HEIGHT) */
  gluOrtho2D(-0.15 * (4 * TC), 1.15 * (4 * TC), -1.1 * XIC.x, 1.1 * XIC.x);

  /* specify window clear (background) color to be white */
  glClearColor(1, 1, 1, 1);

  glutMainLoop();
  return 0;
}
