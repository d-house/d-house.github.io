#include<iostream>
#include<fstream>
#include<math.h>
#include<time.h>

#ifdef __APPLE__
#  pragma clang diagnostic ignored "-Wdeprecated-declarations"
#  include <GLUT/glut.h>
#else
#  include <GL/glut.h>
#endif

#include <cstdlib>

using namespace std;

/******************************************************************

  *****************************************************************/

/* Set main parameters */

// Size of Object to be drawn
#define MASSSIZE 10

// Set screen size
double ImageW = 600;
double ImageH = 600;

// Variables to keep track of simulation parameters
double FrameRate = 30.0;
double StepSize = 0.00001;
double StartDisplacement = 1.0;
double StartVelocity = 0.0;
double MaxTime = 10.0;
int pausestate = 1;

// Variables for Simulation Parameters
double Mass = 1.0;
double SpringConstant = 4.0;
double DamperConstant = 1.0;

// Variables for state of mass (one-dimension example only)
double position;
double velocity;
double acceleration;

// Displacement History List
double* displacementHistory;
double* displacementHistoryTime;
int displacementHistoryCounter=0;

// Variables to keep track of actual time
clock_t lasttime = clock();


void drawtext(string text, float x, float y) {
	int i;

	glRasterPos2f(x,y);

	for(i=0; text[i] != '\0'; i++) {
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12,text[i]);
	}
}

void display(void) {
	int i;
	char s[80];

	glClear(GL_COLOR_BUFFER_BIT);

	// draw spring mass in top of window
	glPointSize(MASSSIZE*sqrt(Mass));
	glViewport(0,ImageH/2,ImageW,ImageH/2);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(StartDisplacement*(-1.1),StartDisplacement*(1.1),-1.0,1.5);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glPushMatrix();
		glBegin(GL_POINTS);
			glVertex2f(position, 0.0);
		glEnd();
		glBegin(GL_LINES);
			glColor3f(1.0, 1.0, 1.0);
			glVertex2f(0.0, 0.0);
			glVertex2f(position, 0.0);

			glColor3f(0.0, 1.0, 0.0);
			glVertex2f(0.0, 0.9);
			glVertex2f(0.0, -0.9);
		glEnd();
	glPopMatrix();

	// draw text for current parameters in top of top window
	glColor3f(1.0,1.0,1.0);
	sprintf(s,"Mass m: %lf",Mass);
	drawtext(s, -1.05*StartDisplacement, 1.35);
	sprintf(s,"Spring Constant k: %lf",SpringConstant);
	drawtext(s, -1.05*StartDisplacement, 1.2);
	sprintf(s,"Damping Constant d: %lf",DamperConstant);
	drawtext(s, -1.05*StartDisplacement, 1.05);

	sprintf(s,"m/d: %lf",Mass/DamperConstant);
	drawtext(s, -0.3*StartDisplacement, 1.35);
	sprintf(s,"m/k: %lf",Mass/SpringConstant);
	drawtext(s, -0.3*StartDisplacement, 1.2);
	sprintf(s,"d/sqrt(km): %lf",DamperConstant/sqrt(SpringConstant*Mass));
	drawtext(s, -0.3*StartDisplacement, 1.05);

	sprintf(s,"Current Time: %lf",displacementHistoryTime[displacementHistoryCounter-1]);
	drawtext(s, 0.35*StartDisplacement, 1.35);
	sprintf(s,"Step Size: %lf",StepSize);
	drawtext(s, 0.35*StartDisplacement, 1.2);
	sprintf(s,"Max Simulation Time: %lf",MaxTime);
	drawtext(s, 0.35*StartDisplacement, 1.05);

	sprintf(s,"Position: %lf",position);
	drawtext(s, -1.05*StartDisplacement, 0.85);
	sprintf(s,"Velocity: %lf",velocity);
	drawtext(s, -1.05*StartDisplacement, 0.70);

	// draw history in bottom of window
	glViewport(0,0,ImageW, ImageH/2);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0-0.1*MaxTime, MaxTime*1.1, StartDisplacement*(-1.1), StartDisplacement*(1.1));
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glPushMatrix();
		glColor3f(0.0, 1.0, 0.0);
		glBegin(GL_LINES);
			// horizontal line at 0
			glVertex2f(-0.05*MaxTime, 0.0);
			glVertex2f(1.05*MaxTime, 0.0);
			// vertical line at 0
			glVertex2f(0.0, 1.05*StartDisplacement);
			glVertex2f(0.0, -1.05*StartDisplacement);
			// lines at +/- StartDisplacement
			glVertex2f(-0.01*MaxTime, StartDisplacement);
			glVertex2f(0.01*MaxTime, StartDisplacement);
			glVertex2f(-0.01*MaxTime, -StartDisplacement);
			glVertex2f(0.01*MaxTime, -StartDisplacement);
		glEnd();

		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_LINE_STRIP);
			for(i=0;i<displacementHistoryCounter;i++) {
				glVertex2f(displacementHistoryTime[i],displacementHistory[i]);
			}
		glEnd();
	glPopMatrix();

	glutSwapBuffers();
}

void stopSim(void) {
}

void getNextPosition(void) {
	// Determine total time to simulate for next frame
	double frametime = 1.0/FrameRate;
	// currenttime keeps track of how much time has been simulated in this step
	double currenttime = 0.0; 

	while (currenttime < frametime) {
		// First determine acceleration
		acceleration = 0.0;
		// spring force
		acceleration -= SpringConstant * position / Mass;
		// damper force
		acceleration -= DamperConstant * velocity / Mass;

		// Now take an Euler step
		double vel;
		double pos;

		vel = velocity + acceleration * StepSize;
		pos = position + velocity * StepSize;

		// Update velocity and position
		velocity = vel;
		position = pos;

		// Update time
		currenttime += StepSize;
	}	// We have simulated a full frame worth of simulation time

	// If we finished too soon, wait until the actual time for next frame to be displayed is reached
	clock_t nexttime = lasttime + frametime * CLOCKS_PER_SEC;
	clock_t curtime = clock();
	while (curtime < nexttime) {
		curtime = clock();
	}
	lasttime = curtime;

	// Update the displacement history
	if ((displacementHistoryTime[displacementHistoryCounter-1] + 1.0/FrameRate) < MaxTime) {
		displacementHistory[displacementHistoryCounter] = position;
		displacementHistoryTime[displacementHistoryCounter] = displacementHistoryTime[displacementHistoryCounter-1] +1.0/FrameRate;
		displacementHistoryCounter++;
	} else {
		// Time to Stop the simulation
		cout << "End of simulation (reached MaxTime)." << endl;
		glutIdleFunc(stopSim);
	}

//	cout << "Time: " << (double)lasttime/(double)CLOCKS_PER_SEC << "  Position: " << position << ", Velocity: " << velocity << endl;

	glutPostRedisplay();
}

void init(void) {
	// initialize graphics
	glShadeModel(GL_FLAT);

	// initialize simulation
	position = StartDisplacement;
	velocity = StartVelocity;

	// initialize history storage
	float framestosimulate = FrameRate * MaxTime;
	int numtostore = int(framestosimulate);
	delete[] displacementHistory;
	delete[] displacementHistoryTime;
	displacementHistory = new double[numtostore];
	displacementHistoryTime = new double[numtostore];
	displacementHistory[0] = StartDisplacement;
	displacementHistoryTime[0] = 0.0;
	displacementHistoryCounter=1;

	cout << "Resetting Simulation Parameters." << endl;
}

void printhelp(void) {
	cout << "Commands for modifying the simulation:" << endl;
	cout << "G/g:      restart simulation" << endl;
	cout << "Space:    pause/unpause simulation" << endl;
	cout << "K/k:      increase/decrease spring constant by factor of 2" << endl;
	cout << "D/d:      increase/decrease damping constant by factor of 2" << endl;
	cout << "M/m:      increase/decrease mass by factor of 2" << endl;
	cout << "S/s:      increase/decrease spring constant by 0.1" << endl;
	cout << "A/a:      increase/decrease damping constant by 0.1" << endl;
	cout << "Q/q:      increase/decrease mass by 0.1" << endl;
	cout << "Z/z:      increase/decrease step size by factor of 2" << endl;
	cout << "Y/y:      increase/decrease step size by 0.01" << endl;
	cout << "X/x:      increase/decrease total simulation time by 1 second" << endl;
	cout << "V/v:      increase/decrease initial velocity by 0.1" << endl;
	cout << "H/h/?     print help message" << endl;
}

void reshape(int w, int h) {
	ImageW = w;
	ImageH = h;
	init();
}

void keyboard(unsigned char key, int x, int y) {

	switch(key) {
    case 27:		// esc - quit
      exit(0);
		case 'g':
		case 'G':
			init();
			glutIdleFunc(getNextPosition);
			pausestate = 0;
			cout << "Restarting Simulation" << endl;
			break;
		case ' ':
			if (pausestate) {
				//Paused, now unpause
				pausestate = 0;
				glutIdleFunc(getNextPosition);
				cout << "Unpaused" << endl;
			} else {
				// Need to pause
				pausestate = 1;
				glutIdleFunc(stopSim);
				cout << "Paused" << endl;
			}
			break;
		case 'k':
			SpringConstant *= 0.5;
			break;
		case 'K':
			SpringConstant *= 2.0;
			break;
		case 'd':
			DamperConstant *= 0.5;
			break;
		case 'D':
			DamperConstant *= 2.0;
			break;
		case 'm':
			Mass *= 0.5;
			break;
		case 'M':
			Mass *= 2.0;
			break;
		case 'S':
			SpringConstant += 0.1;
			break;
		case 's':
			SpringConstant -= 0.1;
			if (SpringConstant < 0.0) SpringConstant = 0.0;
			break;
		case 'A':
			DamperConstant += 0.1;
			break;
		case 'a':
			DamperConstant -= 0.1;
			if (DamperConstant < 0.0) DamperConstant = 0.0;
			break;
		case 'Q':
			Mass += 0.1;
			break;
		case 'q':
			Mass -= 0.1;
			if (Mass < 0.0) Mass = 0.0;
			break;
		case 'x':
			StepSize *= 0.5;
			break;
		case 'X':
			StepSize *= 2.0;
			if (StepSize > 1.0/FrameRate) StepSize = 1.0/FrameRate;
			break;
		case 'y':
			StepSize -= 0.01;
			if (StepSize < 0.0) StepSize = 0.0000001;
			break;
		case 'Y':
			StepSize += 0.01;
			if (StepSize > 1.0/FrameRate) StepSize = 1.0/FrameRate;
			break;
		case 'Z':
			MaxTime += 1.0;
			break;
		case 'z':
			MaxTime -= 1.0;
			if (MaxTime < 0.0) MaxTime = 0.0;
			break;
		case 'V':
			StartVelocity += 0.1;
			break;
		case 'v':
			StartVelocity -= 0.1;
			break;
		case 'H':
		case 'h':
		case '?':
			printhelp();
			break;
	}
	glutPostRedisplay();
}

int main(int argc, char** argv) {
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB);
	glutInitWindowSize(ImageW,ImageH);
	glutInitWindowPosition(100,100);
	glutCreateWindow("Spring Demo");
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);
	printhelp();
	init();	
	glutIdleFunc(stopSim);
	glutMainLoop();
	return 0;
}
