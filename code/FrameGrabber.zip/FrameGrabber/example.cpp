/*
   Sample OpenGL/GLUT Program to Output Animation Frames in HD
 
   Program opens a window and draws a colored square on a white background
 
   'c' keypress - Colors cycle through R, Y, G, C, B, M with 
   'q' or ESC - Program quits
   'r' keypress - Program begins recording frames, one on each call to the display callback

   CP SC 881-05        Donald H. House         11/30/2010
*/

#include <cstdlib>
#include <iostream>

#ifdef __APPLE__
#  include <GLUT/glut.h>
#else
#  include <GL/glut.h>
#endif

using namespace std;

//*************************************************************************
// Your program needs the items between *****'s
// Change the path and base filename for your application
//
// Also see in Display() callback routine: Your program must follow this 
// structure. The display callback does nothing except call a routine that
// is responsible for drawing the current onscreen image, followed by a
// glutSwapBuffers(). After this, if the frame is to be recorded to an image
// file then call the recordimage() method of the framegrabber, with a single
// argument, which is the name of the routine that draws the onscreen image.
//
// In this way, you can have an onscreen image of any desired size, while the
// animation frames can be rendered offscreen at full HD resolution. Of course
// your onscreen viewport's aspect ratio must be the same as the HD image 
// (1920 x 1080) or you will have stretching of the image either vertically or 
// horizontally.
//

#include <Magick++.h>
#include "FrameGrabber.h"

using namespace Magick;

static string MYPATH = "/Users/dhouse/Desktop/animation/";
static string MYFILENAME = "goofy-square";

#define HDWIDTH	      1920		// HD image dimensions
#define HDHEIGHT      1080
#define WIDTH	      (HDWIDTH/2)	// window dimensions = 1/2 HD
#define HEIGHT	      (HDHEIGHT/2)
#define STARTFRAME    0			// first frame number for numbering image files

FrameGrabber framegrabber(MYPATH, MYFILENAME, HDWIDTH, HDHEIGHT, STARTFRAME);
//
//*************************************************************************

static int Recording = false;
static int IColor = 0;

/*
   routine to draw everything in the scene
*/
void DrawEverything(){
  // red, yellow, green, cyan, blue, magenta
  float colors[6][3] = {{1, 0, 0}, {1, 1, 0}, {0, 1, 0},
  {0, 1, 1}, {0, 0, 1}, {1, 0, 1}};

  glClear(GL_COLOR_BUFFER_BIT);  // clear window to background color

  // set the drawing color
  glColor3f(colors[IColor][0], colors[IColor][1], colors[IColor][2]);

  // draw the square
  glBegin(GL_POLYGON);
    glVertex2i(100, 100);
    glVertex2i(100, 500);
    glVertex2i(500, 500);
    glVertex2i(500, 100);
  glEnd();
}

/*
   Display Callback Routine: clear the screen and draw a square
   This routine also records the current image by calling the framegrabber's
   recordimage() method when required.
*/
void Display(){
  DrawEverything();
  glutSwapBuffers();
  
  // recordimage() method needs a pointer to the routine that does all of the drawing
  if(Recording)
    framegrabber.recordimage(DrawEverything);
}

/*
  Keyboard Callback Routine: 'c' cycle through colors, 'q' or ESC quit,
  'r' cycles recording on/off
  This routine is called every time a key is pressed on the keyboard
*/
void handleKey(unsigned char key, int x, int y){
  
  switch(key){
    case 'c':		// 'c' - cycle to next color
    case 'C':
      IColor = (IColor + 1) % 6;
      glutPostRedisplay();
      break;
      
    case 'r':
    case 'R':
      Recording = !Recording;
      glutPostRedisplay();
      break;
      
    case 'q':		// q - quit
    case 'Q':
    case 27:		// esc - quit
      exit(0);
      
    default:		// not a valid key -- just ignore it
      return;
  }
}

/*
   Main program to draw the square, change colors, and wait for quit
*/
int main(int argc, char* argv[]){

  // start up the glut utilities
  glutInit(&argc, argv);

  // create the graphics window, giving width, height, and title text
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
  glutInitWindowSize(WIDTH, HEIGHT);
  glutCreateWindow("A Simple Square");

  // set up the callback routines to be called when glutMainLoop() detects
  // an event
  glutDisplayFunc(Display);	  // display callback
  glutKeyboardFunc(handleKey);	  // keyboard callback

  // define the drawing coordinate system on the viewport
  // lower left is (0, 0), upper right is (WIDTH, HEIGHT)
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(0, WIDTH, 0, HEIGHT);
  glMatrixMode(GL_MODELVIEW);

  // specify window clear (background) color to be opaque white
  glClearColor(1, 1, 1, 1);
  
  // Routine that loops forever looking for events. It calls the registered 
  // callback routine to handle each event that is detected
  glutMainLoop();
  return 0;
}
