/*
 shading.cpp
 
 BIHE Computer Graphics    Donald H. House     6/22/06
 Sample Solution to Homework Assignment #4
 
 OpenGL/GLUT Program to View a 3D cube or teapot in wireframe or shaded view
 
 Keyboard keypresses have the following effects:
 a		- toggle drawing coordinate axes
 c		- toggle between cube and teapot models
 i       	- reinitialize (reset program to initial default state)
 m           - cycle through material colors: white, red, orange, yellow, green, blue, violet
 h		- cycle through shading methods - ambient, diffues, spec_broad, spec_tight, all
 p		- toggle between orthographic and perspective view
 q or Esc	- quit
 s		- toggle between flat shading and smooth shading
 w           - toggle between wireframe and shaded viewing
 
 Camera and model controls following the mouse:
 model yaw   - left-button, horizontal motion, rotation of the model around the y axis
 model tilt  - left-button, vertical motion, rotation of the model about the x axis
 camera yaw  - middle-button, horizontal motion, rotation of the camera about the y axis
 camera tilt	- middle-button, vertical motion, rotation of the camera about the x axis
 approach    - right-button, vertical or horizontal motion, translation of camera along z axis
 
 To compile:
 g++ -o shading shading.cpp Models.o Vector.o Utility.o -lglut -lGL -lm
 */

#include <cstdlib>
#include <cstdio>
#include <iostream>

#ifdef __APPLE__
#  include <GLUT/glut.h>
#else
#  include <GL/glut.h>
#endif

#include "Model.h"

using namespace std;

//*************************************************************************
// Your program needs the items between *****'s
// Change the path and base filename for your application
//
// Also see in Display() callback routine: Your program must follow this 
// structure. The display callback does nothing except call a routine that
// is responsible for drawing the current onscreen image, followed by a
// glutSwapBuffers(). After this, if the frame is to be recorded to an image
// file then call the recordimage() method of the framegrabber, with a single
// argument, which is the name of the routine that draws the onscreen image.
//
// In this way, you can have an onscreen image of any desired size, while the
// animation frames can be rendered offscreen at full HD resolution. Of course
// your onscreen viewport's aspect ratio must be the same as the HD image 
// (1920 x 1080) or you will have stretching of the image either vertically or 
// horizontally.
//

#include <Magick++.h>
#include "FrameGrabber.h"

using namespace Magick;

static string MYPATH = "/Users/dhouse/Desktop/animation/";
static string MYFILENAME = "goofy-cube";

#define HDWIDTH	      1920		// HD image dimensions
#define HDHEIGHT      1080
#define WIDTH	      (HDWIDTH/2)	// window dimensions = 1/2 HD
#define HEIGHT	      (HDHEIGHT/2)
#define STARTFRAME    0			// first frame number for numbering image files

FrameGrabber framegrabber(MYPATH, MYFILENAME, HDWIDTH, HDHEIGHT, STARTFRAME);

int Recording = false;

//
//*************************************************************************

//*****************************************************************
//  Demo Code
//*****************************************************************

#define HORIZONTAL	0
#define VERTICAL	1

#define ESC		27	// numeric code for keyboard Esc key

//#define WIDTH           800	// initial window dimensions
//#define HEIGHT          600

#define ORTHO		0	// projection system codes
#define PERSPECTIVE	1

#define NONE		-1	// used to indicate no mouse button pressed

#define DRAWWIDTH	200	// view volume sizes (note: width and
#define DRAWHEIGHT	150	//   height should be in same ratio as window)
#define NEAR		10	// distance of near clipping plane
#define FAR		1000	// distance of far clipping plane

#define CUBEWIDTH	50	// dimension of the cube
#define DEPTH		-100	// initial z coord. of center of cube

#define ROTFACTOR	0.2     // degrees rotation per pixel of mouse movement
#define XLATEFACTOR	0.5     // units of translation per pixel of mouse movement

#define AMBIENT_FRACTION 0.1
#define DIFFUSE_FRACTION 0.4
#define SPECULAR_FRACTION 0.4

// colors used for lights, and materials for coordinate axes
const float DIM_PALEBLUE[] = {0.1, 0.1, 0.3, 1};
const float BRIGHT_PALEBLUE[] = {0.5, 0.5, 1, 1};
const float GRAY[] = {0.3, 0.3, 0.3, 1};
const float WHITE[] = {1, 1, 1, 1};
const float DIM_WHITE[] = {0.8, 0.8, 0.8, 1};
const float DIM_RED[] = {0.3, 0, 0, 1};
const float RED[] = {1, 0, 0, 1};
const float DIM_GREEN[] = {0, 0.3, 0, 1};
const float GREEN[] = {0, 1, 0, 1};
const float DIM_BLUE[] = {0, 0, 0.3, 1};
const float BLUE[] = {0, 0, 1, 1};

enum COLOR{MAT_WHITE, MAT_RED, MAT_ORANGE, MAT_YELLOW, MAT_GREEN, MAT_BLUE, MAT_VIOLET};

enum SHADEMODE{AMBIENT, DIFFUSE, SPEC_BROAD, SPEC_TIGHT, ALL};

// colors indexed for cycling material colors
float hues[][3] = { {1, 1, 1},    // white
		    {1, 0, 0},    // red
		    {1, 0.5, 0},  // orange
		    {1, 1, 0},    // yellow
		    {0, 1, 0},    // green
		    {0, 0, 1},    // blue
		    {0.5, 0, 1}   // violet
		  };
//
// Global variables updated and shared by callback routines
//

// Window dimensions
static double Width = WIDTH;
static double Height = HEIGHT;

// Viewing parameters
static int Projection;

// Model and Shading parameters
static int CubeModel;
static int Axes;

// Camera position and orientation
static double Pan;
static double Tilt;
static double Approach;

// model orientation
static double ThetaX;
static double ThetaY;

// global variables to track mouse and shift key
static int MouseX;
static int MouseY;
static int Button = NONE;

// global variables to track wireframe/shaded mode and material color
static int Wireframe;
static int MatColor;
static int SmoothShading;
static int ShadeMode;

// global variables to hold geometric models
Model Cube;
Model Cylinder;
Model Cone;

//
// Routine to initialize the state of the program to start-up defaults
//
void setInitialState(){
  
  // initial camera viewing and shading model controls
  Projection = ORTHO;
  
  // model initially wireframe with white color, and flat shading
  Wireframe = true;
  glDisable(GL_LIGHTING);
  glDisable(GL_DEPTH_TEST);
  MatColor = MAT_WHITE;
  ShadeMode = AMBIENT;
  SmoothShading = false;
  
  // initial model is cube and no axes drawn
  CubeModel = true;
  Axes = false;
  
  // initial camera orientation and position
  Pan = 0;
  Tilt = 0;
  Approach = DEPTH;
  
  // initial model orientation
  ThetaX = 0;
  ThetaY = 0;
}

//
// Set up the projection matrix to be either orthographic or perspective
//
void updateProjection(){
  
  // initialize the projection matrix
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  
  // determine the projection system and drawing coordinates
  if(Projection == ORTHO)
    glOrtho(-DRAWWIDTH/2, DRAWWIDTH/2, -DRAWHEIGHT/2, DRAWHEIGHT/2, NEAR, FAR);
  else{
    // scale drawing coords so center of cube is same size as in ortho
    // if it is at its nominal location
    double scale = fabs((double)NEAR / (double)DEPTH);
    double xmax = scale * DRAWWIDTH / 2;
    double ymax = scale * DRAWHEIGHT / 2;
    glFrustum(-xmax, xmax, -ymax, ymax, NEAR, FAR);
  }
  
  // restore modelview matrix as the one being updated
  glMatrixMode(GL_MODELVIEW);
}

//
// routine to draw a set of coordinate axes centered at the origin
//
void drawAxes(float size, int wireframe){
  if(wireframe){     // wireframe drawing, so draw X, Y, Z axes as colored lines
    glBegin(GL_LINES);
    glColor3f(1, 0, 0);		  // x axis drawn in red
    glVertex3f(0, 0, 0);
    glVertex3f(size, 0, 0);
    
    glColor3f(0, 1, 0);		  // y axis drawn in green
    glVertex3f(0, 0, 0);
    glVertex3f(0, size, 0);
    
    glColor3f(0, 0, 1);		  // z axis drawn in blue
    glVertex3f(0, 0, 0);
    glVertex3f(0, 0, size);
    glEnd();
  }
  else{      // shaded drawing, so draw X, Y, Z axes as solid arrows
    const float height = size;
    
    // draw arrow shafts. they are all white
    glMaterialfv(GL_FRONT, GL_AMBIENT, GRAY);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, WHITE);
    // Z
    Cylinder.Draw(false);
    // X
    glPushMatrix();
    glRotatef(90, 0, 1, 0);
    Cylinder.Draw(false);
    glPopMatrix();
    // Y
    glPushMatrix();
    glRotatef(-90, 1, 0, 0);
    Cylinder.Draw(false);
    glPopMatrix();
    
    // draw arrow heads. X is red, Y is green, and Z is blue
    // Z
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_AMBIENT, DIM_BLUE);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, BLUE);
    glTranslatef(0, 0, 0.8 * height);
    Cone.Draw(false);
    glPopMatrix();
    // X
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_AMBIENT, DIM_RED);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, RED);
    glRotatef(90, 0, 1, 0);
    glTranslatef(0, 0, 0.8 * height);
    Cone.Draw(false);
    glPopMatrix();
    // Y
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_AMBIENT, DIM_GREEN);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, GREEN);
    glRotatef(-90, 1, 0, 0);
    glTranslatef(0, 0, 0.8 * height);
    Cone.Draw(false);
    glPopMatrix();
  }
}

//
// routine to draw the current model
//
void drawModel(int cubemodel, int wireframe){
  float ambient_color[4];
  float diffuse_color[4];
  float specular_color[4];
  int shininess;
  
  if(wireframe){
    // set drawing color to current hue, and draw with thicker wireframe lines
    glColor3f(hues[MatColor][0], hues[MatColor][1], hues[MatColor][2]);
    glLineWidth(2);
  }
  else{
    // set up material colors to current hue.
    for(int i = 0; i < 3; i++)
      ambient_color[i] = diffuse_color[i] = specular_color[i] = 0;
    ambient_color[3] = diffuse_color[3] = specular_color[3] = 1;
    shininess = 1;
    
    switch(ShadeMode){
      case AMBIENT:
	for(int i = 0; i < 3; i++)
	  ambient_color[i] = AMBIENT_FRACTION * 3 * hues[MatColor][i];
	break;
	
      case DIFFUSE:
	for(int i = 0; i < 3; i++){
	  ambient_color[i] = AMBIENT_FRACTION * hues[MatColor][i];
	  diffuse_color[i] = DIFFUSE_FRACTION * 2 * hues[MatColor][i];
	}
	break;
	
      case SPEC_BROAD:
	for(int i = 0; i < 3; i++){
	  ambient_color[i] = AMBIENT_FRACTION * hues[MatColor][i];
	  specular_color[i] = SPECULAR_FRACTION * 2 * hues[MAT_WHITE][i];
	  shininess = 10;
	}
	break;
	
      case SPEC_TIGHT:
	for(int i = 0; i < 3; i++){
	  ambient_color[i] = AMBIENT_FRACTION * hues[MatColor][i];
	  specular_color[i] = SPECULAR_FRACTION * 2 *hues[MAT_WHITE][i];
	  shininess = 60;
	}
	break;
	
      case ALL:
	for(int i = 0; i < 3; i++){
	  ambient_color[i] = AMBIENT_FRACTION * hues[MatColor][i];
	  diffuse_color[i] = DIFFUSE_FRACTION * hues[MatColor][i];
	  specular_color[i] = SPECULAR_FRACTION * hues[MAT_WHITE][i];
	  shininess = 60;
	}
	break;
    }
    
    glMaterialfv(GL_FRONT, GL_AMBIENT, ambient_color);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse_color);
    glMaterialfv(GL_FRONT, GL_SPECULAR, specular_color);
    glMaterialf(GL_FRONT, GL_SHININESS, shininess);
  }
  
  if(cubemodel)
    Cube.Draw(wireframe);
  else if(wireframe)
    glutWireTeapot(3 * CUBEWIDTH / 5);
  else
    glutSolidTeapot(3 * CUBEWIDTH / 5);
}

//
// The drawing code called by the drawing callback and framegrabber
//
void DrawEverything(){
  // distant light source, parallel rays coming from front upper right
  const float light_position[] = {1, 1, 1, 0};
  
  // clear the window to the background color
  glClear(GL_COLOR_BUFFER_BIT);
  
  if(!Wireframe)
    glClear(GL_DEPTH_BUFFER_BIT);  // solid - clear depth buffer
  
  if(!Wireframe && SmoothShading)  // establish shading model, flat or smooth
    glShadeModel(GL_SMOOTH);
  else
    glShadeModel(GL_FLAT);
  
  // light is positioned in camera space so it does not move with object
  glLoadIdentity();
  glLightfv(GL_LIGHT0, GL_POSITION, light_position);
  glLightfv(GL_LIGHT0, GL_AMBIENT, WHITE);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, WHITE);
  glLightfv(GL_LIGHT0, GL_SPECULAR, WHITE);
  
  // establish camera coordinates
  glRotatef(Tilt, 1, 0, 0);	    // tilt - rotate camera about x axis
  glRotatef(Pan, 0, 1, 0);	    // pan - rotate camera about y axis
  glTranslatef(0, 0, Approach);     // approach - translate camera along z axis
  
  // rotate the model
  glRotatef(ThetaY, 0, 1, 0);       // rotate model about x axis
  glRotatef(ThetaX, 1, 0, 0);       // rotate model about y axis
  
  // draw the model in wireframe or solid
  drawModel(CubeModel, Wireframe);
  
  // if axes are required, draw them
  if(Axes)
    drawAxes(0.8 * CUBEWIDTH, Wireframe);
}

/*
 Display Callback Routine: clear the screen and draw a square
 This routine also records the current image by calling the framegrabber's
 recordimage() method when required.
 */
void doDisplay(){
  DrawEverything();
  glutSwapBuffers();
  
  // recordimage() method needs a pointer to the routine that does all of the drawing
  if(Recording)
    framegrabber.recordimage(DrawEverything);
}

//
// Keyboard callback routine. 
// Set various modes or take actions based on key presses
//
void handleKey(unsigned char key, int x, int y){
  
  switch(key){
      
    case 'a':			// A -- toggle between drawing axes or not
    case 'A':
      Axes = !Axes;
      glutPostRedisplay();
      break;
      
    case 'r':			// R -- toggle between recording or not
    case 'R':
      Recording = !Recording;
      glutPostRedisplay();
      break;
      
    case 'p':			// P -- toggle between ortho and perspective
    case 'P':
      Projection = !Projection;
      updateProjection();
      glutPostRedisplay();
      break;
      
    case 'c':			// C -- toggle between cube and teapot models
    case 'C':
      CubeModel = !CubeModel;
      glutPostRedisplay();
      break;
      
    case 'i':			// I -- reinitialize 
    case 'I':
      setInitialState();
      updateProjection();
      glutPostRedisplay();
      break;
      
    case 'm':			// M -- cycle through material colors
    case 'M':
      MatColor = (MatColor == MAT_VIOLET? MAT_WHITE: MatColor + 1);
      glutPostRedisplay();
      break;
      
    case 'h':			// H -- cycle through shading modes
    case 'H':
      ShadeMode = (ShadeMode == ALL? AMBIENT: ShadeMode + 1);
      switch(ShadeMode){
	case AMBIENT:
	  cout << "Ambient" << endl;
	  break;
	case DIFFUSE:
	  cout << "Diffuse" << endl;
	  break;
	case SPEC_BROAD:
	  cout << "Specular - broad" << endl;
	  break;
	case SPEC_TIGHT:
	  cout << "Specular - tight" << endl;
	  break;
	case ALL:
	  cout << "A + D + S" << endl;
	  break;
      }
      glutPostRedisplay();
      break;
      
    case 'q':			// Q or Esc -- exit program
    case 'Q':
    case ESC:
      exit(0);
      
    case 's':			// S -- toggle between flat and smooth shading
    case 'S':
      SmoothShading = !SmoothShading;
      glutPostRedisplay();
      break;
      
    case 'w':			// M -- toggle between wireframe and shaded viewing
    case 'W':
      Wireframe = !Wireframe;
      if(Wireframe){
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
      }
      else{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
      }
      glutPostRedisplay();
      break;
  }
}

//
// Mouse Button Callback
// on button press, record mouse position and which button is pressed
//
void handleButtons(int button, int state, int x, int y){
  
  if(state == GLUT_UP)
    Button = NONE;		// no button pressed
  else{
    MouseY = -y;		// invert y window coordinate to correspond with OpenGL
    MouseX = x;
    
    Button = button;		// store which button pressed
  }
}

//
// Mouse Motion Callback
// when mouse moves with a button down, update appropriate camera parameter
//
void handleMotion(int x, int y){
  int delta;
  
  y = -y;
  int dy = y - MouseY;
  int dx = x - MouseX;
  
  switch(Button){
    case GLUT_LEFT_BUTTON:
      ThetaX -= ROTFACTOR * dy;
      ThetaY += ROTFACTOR * dx;
      glutPostRedisplay();
      break;
    case GLUT_MIDDLE_BUTTON:
      Pan -= ROTFACTOR * dx;
      Tilt += ROTFACTOR * dy;
      glutPostRedisplay();
      break;
    case GLUT_RIGHT_BUTTON:
      delta = (fabs(dx) > fabs(dy)? dx: dy);
      Approach += XLATEFACTOR * delta;
      glutPostRedisplay();
      break;
  }
  
  MouseX = x;
  MouseY = y;
}

//
// Reshape Callback
// Keep viewport the entire screen
//
void doReshape(int width, int height){
  
  glViewport(0, 0, width, height);
  Width = width;
  Height = height;
  
  updateProjection();
}

//
// Initialize OpenGL to establish lighting and colors
// and initialize viewing and model parameters
//
void initialize(){
  
  // initialize modelview matrix to identity
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  
  // specify window clear (background) color to be black
  glClearColor(0, 0, 0, 1.0);
  
  // local lighting, consider position of light in specular shading
  glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
  
  // position light and turn it on
  glEnable(GL_LIGHT0);
  
  // initialize viewing and model parameters
  setInitialState();
  updateProjection();
  
  // construct the models that will be used
  Cube.BuildCuboid(CUBEWIDTH, CUBEWIDTH, CUBEWIDTH);    // cube
  Cylinder.BuildCylinder(0.8 * CUBEWIDTH / 20.0, 1.24 * CUBEWIDTH); // cylinder for axes
  Cone.BuildCone(0.8 * CUBEWIDTH / 10.0, 0.16 * CUBEWIDTH); // cone for axes
}

//
// Main program to create window, setup callbacks, and initiate GLUT
//
int main(int argc, char* argv[]){
  
  // start up the glut utilities
  glutInit(&argc, argv);
  
  // create the graphics window, giving width, height, and title text
  // and establish double buffering, RGBA color
  // Depth buffering must be available for drawing the shaded model
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
  glutInitWindowSize(WIDTH, HEIGHT);
  glutCreateWindow("3D Shaded and Wireframe Viewer");
  
  // register callback to draw graphics when window needs updating
  glutDisplayFunc(doDisplay);
  glutReshapeFunc(doReshape);
  glutKeyboardFunc(handleKey);
  glutMouseFunc(handleButtons);
  glutMotionFunc(handleMotion);
  
  initialize();
  
  glutMainLoop();
}
